package com.company;

import kg.geektech.homework.rpg.*;

public class Main {

    public static void main(String[] args) {
        RPG_GAME.startGame();


    }

}

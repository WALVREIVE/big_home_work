package kg.geektech.homework.rpg;

public enum SuperAbility {
    BOOST , HEAL , CRITICAL_DAMAGE , SAVE_DAMAGE_AND_REVERT
}

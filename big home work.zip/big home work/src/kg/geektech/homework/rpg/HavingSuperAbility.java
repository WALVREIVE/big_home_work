package kg.geektech.homework.rpg;

public interface HavingSuperAbility {
    void applySuperPower(Hero[] heroes, Boss boss);
}
